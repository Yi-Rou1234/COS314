public class Main {
    public static void main(String[] args) {
        ILS ils = new ILS();
        ils.run();
        SA sa = new SA();
        sa.run();
    }
}
